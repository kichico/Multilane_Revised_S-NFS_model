#include "Multilane_TrafficFlow.h"

int main() {
	Multilane_TrafficFlow mt;
	mt.Calculation(300, 300, 1);
	return 0;
}